<?php
/** 
 * 
 * electrothemetopsellings.php
 * 
 * Language file for a front page.
 * 
*/

$_['heading_title']         = 'Electro Theme - Top Sellings';
$_['section_title']         = 'Самые продаваемые';
$_['text_all_categories']   = 'Все категории';